
$(document).ready(function(){
    
    // Menu toggle button
    $(".nav-btn").click(function(){
        $(".navigation").slideToggle();
    });
    
    // fixed header

    
    
    
});